﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MongoDB.Driver;
using britehouse_project.Models;
using britehouse_project.App_Start;
using britehouse_project.View_Models;
using PagedList;
using PagedList.Mvc;

namespace britehouse_project.Controllers
{
   
    public class peopleController : Controller
    {
        peopleViewModel viewPeople = new peopleViewModel();
        
        private MongoDBContext dBContext;
        private IMongoCollection<people> peopleCollection;
        // GET: people
        public peopleController()
        {
            dBContext = new MongoDBContext();
            peopleCollection = dBContext.database.GetCollection<people>("peoplereviews");
        }
        public ActionResult peopleIndex()
        {
            List<people> mypeople = peopleCollection.AsQueryable<people>().ToList();

            int totalAfrica = (from x in mypeople.Where(x => x.Region.Contains("Africa")) select x.Person).Count();
            int totalEurope = (from x in mypeople.Where(x => x.Region.Contains("Europe")) select x.Person).Count();
            int totalAmerica = (from x in mypeople.Where(x => x.Region.Contains("America")) select x.Person).Count();
            int totalAsia = (from x in mypeople.Where(x => x.Region.Contains("Asia")) select x.Person).Count();
            int totalCanada = (from x in mypeople.Where(x => x.Region.Contains("Canada")) select x.Person).Count();
            int totalOceania = (from x in mypeople.Where(x => x.Region.Contains("Oceania")) select x.Person).Count();

            viewPeople.Africa_count = totalAfrica;
            viewPeople.Europe_count = totalEurope;
            viewPeople.America_count = totalAmerica;
            viewPeople.Asia_count = totalAsia;
            viewPeople.Canada_count = totalCanada;
            viewPeople.Oceania_count = totalOceania;

            return View(viewPeople);
        }

        public ActionResult Index(string search,int? page)
        {
            List<people> mypeople = peopleCollection.AsQueryable<people>().ToList();
            return View(mypeople.ToList().ToPagedList(page ?? 1, 5));

        }
    }
}