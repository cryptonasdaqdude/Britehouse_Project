﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MongoDB.Driver;
using britehouse_project.Models;
using britehouse_project.App_Start;
using britehouse_project.View_Models;
using PagedList.Mvc;
using PagedList;


namespace britehouse_project.Controllers
{
    public class returnsController : Controller
    {
        returnsViewModel viewReturns = new returnsViewModel();
        private MongoDBContext dBContext;
        private IMongoCollection<returns> returnsCollection;

        // GET: returns
        public returnsController()
        {
            dBContext = new MongoDBContext();
            returnsCollection = dBContext.database.GetCollection<returns>("returnsreviews");
        }

        public ActionResult returnsIndex()
        {
            List<returns> mypeople = returnsCollection.AsQueryable<returns>().ToList();

            int totalAfrica = (from x in mypeople.Where(x => x.Region.Contains("Africa")) select x.Order_ID).Count();
            int totalEurope = (from x in mypeople.Where(x => x.Region.Contains("Europe")) select x.Order_ID).Count();
            int totalAmerica = (from x in mypeople.Where(x => x.Region.Contains("America")) select x.Order_ID).Count();
            int totalAsia = (from x in mypeople.Where(x => x.Region.Contains("Asia")) select x.Order_ID).Count();
            int totalCanada = (from x in mypeople.Where(x => x.Region.Contains("Canada")) select x.Order_ID).Count();
            int totalOceania = (from x in mypeople.Where(x => x.Region.Contains("Oceania")) select x.Order_ID).Count();
            int totalUS = (from x in mypeople.Where(x => x.Region.Contains("US")) select x.Order_ID).Count();
            int totalCaribbean = (from x in mypeople.Where(x => x.Region.Contains("Caribbean")) select x.Order_ID).Count();
            

            viewReturns.Africa_count = totalAfrica;
            viewReturns.Europe_count = totalEurope;
            viewReturns.America_count = totalAmerica;
            viewReturns.Asia_count = totalAsia;
            viewReturns.Canada_count = totalCanada;
            viewReturns.Oceania_count = totalOceania;
            viewReturns.US_count = totalUS;
            viewReturns.Carribean_count = totalCaribbean;

            return View(viewReturns);
        }
    }
}