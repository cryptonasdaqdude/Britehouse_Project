﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MongoDB.Driver;
using britehouse_project.Models;
using britehouse_project.App_Start;
using britehouse_project.View_Models;
using PagedList.Mvc;
using PagedList;


namespace britehouse_project.Controllers
{
    public class ordersController : Controller
    {
        ordersViewModel vieworders = new ordersViewModel();
        private MongoDBContext dBContext;
        private IMongoCollection<orders> ordersCollection;

        // GET: orders
        public ordersController()
        {
            dBContext = new MongoDBContext();
            ordersCollection = dBContext.database.GetCollection<orders>("ordersreviews");

        }
        
        public ActionResult ordersIndex(int? i)
        {
            List<orders> myorders = ordersCollection.AsQueryable<orders>().ToList();

            int total2012 = (from x in myorders.Where(x => x.Order_Date.Contains("2012")) select x.Row_ID).Count();

            int total2013 = (from x in myorders.Where(x => x.Order_Date.Contains("2013")) select x.Row_ID).Count();

            int total2014 = (from x in myorders.Where(x => x.Order_Date.Contains("2014")) select x.Row_ID).Count();

            int total2015 = (from x in myorders.Where(x => x.Order_Date.Contains("2015")) select x.Row_ID).Count();

            vieworders.count2012 = total2012;
            vieworders.count2013 = total2013;
            vieworders.count2014 = total2014;
            vieworders.count2015 = total2015;
            
            return View(myorders.ToList().ToPagedList(i ?? 1,200));
        }
    }
}