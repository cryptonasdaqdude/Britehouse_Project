﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace britehouse_project.View_Models
{
    public class returnsViewModel
    {
        public int Africa_count { get; set; }

        public int Europe_count { get; set; }

        public int America_count { get; set; }

        public int Asia_count { get; set; }

        public int Canada_count { get; set; }

        public int Oceania_count { get; set; }

        public int US_count { get; set; }

        public int Carribean_count { get; set; }
    }
}