﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace britehouse_project.View_Models
{
    public class ordersViewModel
    {
        public int count2012 { get; set; }

        public int count2013 { get; set; }

        public int count2014 { get; set; }

        public int count2015 { get; set; }
    }
}